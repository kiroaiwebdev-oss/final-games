PlayHop build — Playgama Bridge
================================
Download the official "bridge.js" from the Playgama Bridge releases:
  https://github.com/Playgama/bridge/releases
Place bridge.js in this folder (next to index.html), then re-zip the folder.

The game runs without it (clean fallback), but for PlayHop monetization and
cloud save you should bundle the official bridge.js.